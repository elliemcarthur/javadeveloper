package CoreJava.Models;

import java.util.Scanner;

public class Student {
	
	private String email;
	private String name;
	private String pass;
	
	public Student() {
		Scanner reader=new Scanner(System.in);
		System.out.println("Enter name:");
		setName(reader.nextLine());
		System.out.println("Enter email:");
		setEmail(reader.nextLine());
		System.out.println("Enter pass:");
		setPass(reader.nextLine());
		
	}
	
	public Student(String name, String email, String pass) {
		this.name=name;
		this.email=email;
		this.pass=pass;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getPass() {
		return pass;
	}
	public void setPass(String pass) {
		this.pass = pass;
	}
	


}
