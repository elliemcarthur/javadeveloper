package org.perscholas.JDBC1;


import java.sql.Connection;
import java.sql.DriverManager;


public abstract class AbstractDAO {
protected Connection conn;
public void getConnection() {
	try {
		Class.forName("oracle.jdbc.driver.OracleDriver");
		String url= "jdbc:oracle:thin:@localhost:1521:xe";
		String user="System";
		String pass="Password1";
		
		conn=DriverManager.getConnection(url, user, pass);
		
		
	} catch (Exception e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	}

public void closeConnection() {
	
	try {
		conn.close();
	} catch (Exception e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
}
}
