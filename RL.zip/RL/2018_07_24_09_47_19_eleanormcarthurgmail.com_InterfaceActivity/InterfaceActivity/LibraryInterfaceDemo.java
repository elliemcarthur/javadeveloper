package org.perscholas.InterfaceActivity;

public class LibraryInterfaceDemo {

	public static void main(String[] args) {
		//test case #1
		KidUser kid1=new KidUser();
		kid1.setAge(10);
		kid1.registerAccount();
		
		
		KidUser notkid=new KidUser();
		notkid.setAge(18);
		notkid.registerAccount();
		
		kid1.setBookType("Kids");
		kid1.requestBook();
		kid1.setBookType("Fiction");
		kid1.requestBook();
		
		//test case #2
		
		AdultUser notadult=new AdultUser();
		notadult.setAge(5);
		notadult.registerAccount();
		
		AdultUser adult1=new AdultUser();
		adult1.setAge(23);
		adult1.registerAccount();
		adult1.setBookType("Kids");
		adult1.requestBook();
		adult1.setBookType("Fiction");
		adult1.requestBook();

	}

}
