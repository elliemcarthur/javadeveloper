package Core.MainEntryPoint;


import CoreJava.DAO.AttendingDAO;
import CoreJava.DAO.CourseDAO;
import CoreJava.DAO.StudentDAO;
import CoreJava.Models.Attending;
import CoreJava.Models.Course;
import CoreJava.Models.Student;

import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class TestRunner {
    public static void main(String[] args) {
    	Student student=new Student("Ellie", "e@mail.com", "11234");
    	Student student2=new Student("Elly", "ally@mail.com", "11334");
    	Student student3=new Student("Ally", "allie@gmail.com", "22334");
    	ArrayList<Student> studList=new ArrayList<Student>();
    	studList.add(student);
    	studList.add(student2);
    	studList.add(student3);
        System.out.println("Are you a(n)");
       String studentEmail= "ally@mail.com";
       String stuPW="11334";
 
        	
        Course course1=new Course(1, "Gym", "Brown");
        Course course2=new Course(2, "Math", "Rick");
        Course course3=new Course(3, "English", "Rob");
       // ArrayList<Course> courseList=new ArrayList<Course>();
       // courseList.add(course1);
       // courseList.add(course2);
       // courseList.add(course3);
        StudentDAO studentDAO= new StudentDAO();
       
		try {
		List<Student> StuList = studentDAO.getStudents();
			for (Student stu : StuList) {
			System.out.println(stu.getPass());
		}
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
       
		
    }
}
