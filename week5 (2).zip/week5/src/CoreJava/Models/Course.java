package CoreJava.Models;

import java.util.Scanner;

import org.perscholas.files.Student;

public class Course {
	
	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getInstuctor() {
		return instuctor;
	}

	public void setInstuctor(String instuctor) {
		this.instuctor = instuctor;
	}

	public int id;
	public String name;
	public String instuctor;
	
	
	public  Course(){
		Scanner reader= new Scanner(System.in);
		System.out.println("Input Id.");
		setId(reader.nextInt());
		System.out.println("Input Name.");
		setName(reader.nextLine());
		System.out.println("Input Instructor.");
		setInstuctor(reader.nextLine());
		
	}
	
	public Course(int id, String name, String instructor) {
		this.id=id;
		this.name=name;
		this.instuctor=instructor;
	}


}
