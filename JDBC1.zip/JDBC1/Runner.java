package org.perscholas.JDBC1;



public class Runner {

	public static void main(String[] args) {
		ItemDAO itemDAO1=new ItemDAO();
		Item item=itemDAO1.getItemById(1);
		System.out.println(item.getId());
		
		

	}

}
