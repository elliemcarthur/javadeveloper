package CoreJavaDAO;

import CoreJava.Models.Student;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class StudentDAO {
    public List<String>  getStudents() throws FileNotFoundException{
    	String fileLocation = "C:\\Users\\Students\\eclipse-workspace\\week5\\src\\Core\\MainEntryPoint\\";
		String stufile = "Students.csv";
		File file = new File(fileLocation,stufile);
		List<String> data=new ArrayList<String>();
		Scanner reader = new Scanner(file);
		while (reader.hasNextLine()) {
			data.add(reader.nextLine());
		}	
		reader.close();
		return data;
    	

    }

    public Student getStudentByEmail(List<Student> studentList, String studentEmail){
    	Student studenttoparse = null;
    	for( int i =0;i<studentList.size(); i++) {
    		while(studentList.get(i).getEmail().contains(studentEmail)) {
    			 studenttoparse= studentList.get(i);
    			
    		}
    	}
    	return studenttoparse;
    }
    
    public boolean validateUser(List<Student> studentList, String studentEmail, String studentPass){
        	for(Student student:studentList) {
    		if(student.getEmail().equals(studentEmail) &&
    				student.getPass().equals(studentPass)){
    			return true;
    		
    	}else 
    	{return false;}

    }
}
}