package CoreJava.DAO;

import CoreJava.Models.Course;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class CourseDAO {
    public List<Course> getAllCourses() throws FileNotFoundException{
    	String fileLocation = "C:\\Users\\Robyn\\Documents\\GitHub\\javadeveloper\\week5 (3)\\week5\\src\\Core\\MainEntryPoint";
		String coursefile = "courses.csv";
		File file=new File(fileLocation, coursefile);
		Scanner input=new Scanner(file);
        List<Course> courseList=new ArrayList<Course>();
        while(input.hasNext()) {
        	String[] lines=input.next().split("|");
        	Course course= new Course();
        	course.setId((Integer.valueOf(lines[0])));
        	//maybe issue here
        	course.setName(lines[1]);
        	course.setInstructor(lines[2]);
        	courseList.add(course);
        }
           input.close();
           return courseList;
    }
}
