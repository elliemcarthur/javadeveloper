package CoreJava.DAO;

import CoreJava.Models.Student;

import java.io.File;
import java.io.FileNotFoundException;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class StudentDAO {
    public List<Student>  getStudents() throws FileNotFoundException {
    	String fileLocation = "C:\\Users\\Robyn\\Documents\\GitHub\\javadeveloper\\week5 (3)\\week5\\src\\Core\\MainEntryPoint";
		String stufile = "students.csv";
		File file = new File(fileLocation,stufile);
		List<Student> studentData=new ArrayList<Student>();
		Scanner reader = new Scanner(file);
		while (reader.hasNextLine()) {
			String[] lines=reader.nextLine().split(",");
			Student student= new Student();
			student.setEmail(lines[0]);
			student.setName(lines[1]);
			student.setPass(lines[2]);
			studentData.add(student);
		}	
	
		reader.close();
		return studentData;
    	

    }

    public Student getStudentByEmail(List<Student> studentList, String studentEmail){
    	Student studenttoparse = null;
    	    
for( int i =0;i<studentList.size(); i++) {
	if(studentEmail.equals(studentList.get(i).getEmail())) {
    			
    				studenttoparse= studentList.get(i);
    				}
    				else {
    					continue;
    				}
    				    	    		}
    		return studenttoparse;
    	}
    	
    
    
    public boolean validateUser(List<Student> studentList, String studentEmail, String studentPass){
    	boolean needvalidate = false;
       for(Student student2:studentList) {
    		if(student2.getEmail().contains(studentEmail) && student2.getPass().contains(studentPass)){
    			needvalidate=true;
    		}else {
    			continue;
    		}
       }
       return needvalidate;
    }
}
