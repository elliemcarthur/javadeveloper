package CoreJavaDAO;

import java.util.Scanner;

public class Attending {
	String courseId;
	String email;
	
	public Attending(){
		Scanner reader= new Scanner(System.in);
		System.out.println("Input Course Id.");
		setCourseId(reader.nextLine());
		System.out.println("Input Email");
		setEmail(reader.nextLine());
			
		
	}
	public String getCourseId() {
		return courseId;
	}
	public void setCourseId(String courseId) {
		this.courseId = courseId;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	


}
