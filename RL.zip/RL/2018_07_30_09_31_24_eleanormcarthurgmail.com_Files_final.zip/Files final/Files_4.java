package org.perscholas.files;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Scanner;

public class Files_4 {


	

	public static <T> ArrayList<T> readFile(String fileLocation, String FileName, T value) throws FileNotFoundException {
		ArrayList<T> nameArray = new ArrayList<T>();
		File file = new File(fileLocation+FileName);
		
		Scanner reader = new Scanner(file);
		while (reader.hasNextLine()) {
			nameArray.add((T)reader.nextLine());
		}	
		reader.close();
		return nameArray;
	} 

	public static void main(String[] args) throws FileNotFoundException {
		String fileLocation = "C:\\Users\\Students\\eclipse-workspace\\PerScholas\\src\\org\\perscholas\\files\\";
		String namefile = "names.csv";
		String gradefile = "grades.csv";
		String fileGpa = "gpas.csv";
		
		
		Student[] students=new Student[10];
			    students[0]=new Student("Josh", 12, 100);
			    students[1]=new Student("Jerry", 12, 90);
			    students[2]=new Student("Jet", 12, 89);
			    students[3]=new Student("Ellie", 12, 91);
			    students[4]=new Student("Robyn", 12, 96);
			    students[5]=new Student("Robert", 12, 78);
			    students[6]=new Student("Kyle", 12, 89);
			    students[7]=new Student("Eli", 12, 91);
			    students[8]=new Student("Kumar", 12, 70);
			    students[9]=new Student("Kiki", 12, 91);
			    
	   File file= new File(fileLocation, namefile);
	   File file2=new File(fileLocation, gradefile); 
	   File file3=new File(fileLocation, fileGpa);
		try {

		FileWriter	writer = new FileWriter(file, true);	
		
		for(int m=0; m<students.length; m++) {
			writer.write(students[m].getName() + "\n");
			}
		
		
		FileWriter writergrade=new FileWriter(file2, true);
		for(int k=0; k< students.length; k++) {
		writergrade.write(students[k].getGrade() + "\n");
		}
		
	
		FileWriter writergpa=new FileWriter(file3, true);
		for(int p=0; p<students.length; p++) {
		writergpa.write(String.valueOf(students[p].getGpa()) + "\n");
		}
		
			writer.close();
		writergrade.close();
		writergpa.close();
		
			ArrayList<String> nameArray;
		ArrayList<Integer> gradeArray;
		ArrayList<Double> gpasArray;
		
		nameArray=readFile(fileLocation, namefile, "");
     	gradeArray = readFile(fileLocation, gradefile, 0);
		gpasArray = readFile(fileLocation, fileGpa, 0.0);
		Student[] studentArray = new Student[nameArray.size()];

		
		for (String name : nameArray) {
			System.out.println(name);
		}
		
		for (int j = 0; j < gradeArray.size(); j++) {
			System.out.println(gradeArray.get(j));
		}
		
		for (int j = 0; j < gpasArray.size(); j++) {
			System.out.println(gpasArray.get(j));
		}

		
	for(int h=0; h< students.length; h++) {
		students[h].getInfo();
	}
		}
		catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		}
	}

	
//try changing to object for 5
