package org.perscholas.JDBC1;

abstract class AbstractDao{

}
