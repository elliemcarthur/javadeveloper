package CoreJava.DAO;

import CoreJava.Models.Attending;
import CoreJava.Models.Course;


import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class AttendingDAO {

    public List<Attending> getAttending() throws FileNotFoundException{
   
    	String fileLocation = "C:\\Users\\Robyn\\Documents\\GitHub\\javadeveloper\\week5 (3)\\week5\\src\\Core\\MainEntryPoint\\";
		String attendfile = "attending.csv";
		File file = new File(fileLocation,attendfile);
		Scanner input=new Scanner(file);
		ArrayList<Attending> attendingList=new ArrayList<Attending>();
		while(input.hasNextLine()) {
			String[] lines=input.nextLine().split(",");
			Attending attending=new Attending();
			attending.setCourseId(Integer.valueOf(lines[0]));
			attending.setEmail(lines[1]);
			attendingList.add(attending);
			
		}
	
		input.close();
		return attendingList;
	
    }

    public void registerStudentToCourse(List<Attending> attending, String studentEmail, int courseID) throws IOException{
    	for(Attending attend: attending){
    	if(studentEmail.equals(attend.getEmail()) && courseID==attend.getCourseId()){
    		System.out.println("Student with that email is currently attending that course.");
    	}else {
    		Attending attendant= new Attending();
    		attendant.setEmail(studentEmail);
    		attendant.setCourseId(courseID);
    		attending.add(attendant);
    		saveAttending(attending);
    	
    	}
    	}

    }

    public List<Course> getStudentCourses(List<Course> courseList, List<Attending> attending, String studentEmail){
    					for(int x=0; x<attending.size(); x++) {
    						if(studentEmail.equals(attending.get(x).getEmail())) {
    							
    							
    							Course course=new Course();
    							course.setId(attending.get(x).getCourseId());
    							for(Course courseoffered: courseList) {
    								if(course.getId()==courseoffered.getId()) {
    									course.setName(courseoffered.getName());
    									course.setInstructor(courseoffered.getInstructor());
    									courseList.add(course);
    								}else {
    									courseList.add(course);
    								}
    							}
    							
    						}
    					}
    					return courseList;
    }

    public void saveAttending(List<Attending> attending) throws IOException{
     	String fileLocation = "C:\\\\Users\\\\Students\\\\eclipse-workspace\\\\week5\\\\src\\\\Core\\\\MainEntryPoint\\\\";
    		String attendfile = "attending.csv";
    		File file=new File(fileLocation, attendfile);
    		FileWriter fw= new FileWriter(file, false);
    		for(int y=0; y<attending.size(); y++) {
    			fw.write(attending.get(y).getCourseId() + ",");
    			fw.write(attending.get(y).getEmail() + "\n");
    		}
    		fw.close();

    }

}
