package org.perscholas.JDBC1;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class ItemDAO extends AbstractDAO implements ItemDAOI {
	
	public Item getItemById(int id){
	getConnection();
	Item item = null;
	PreparedStatement ps;
	try {
		ps = conn.prepareStatement(SQL.GETITEMBYID.getQuery());
		ps.setInt(1,id);
	ResultSet rs=ps.executeQuery();
	while(rs.next()) {
		item=new Item();
		item.setId(rs.getInt(1));
		item.setName(rs.getString(2));
		item.setQuantity_in_stock(rs.getInt(3));
		item.setPrice(rs.getDouble(4));
		
	}
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}finally {
		closeConnection();
	}
	return item;
	
	
}

	public List <Item >	getItemsCostingGreaterThan(double price){
		getConnection();
		ArrayList<Item> items=new ArrayList<Item>();
		PreparedStatement ps;
		
		try {
			ps =conn.prepareStatement(SQL.GETITEMSCOSTINGGREATERTHAN.getQuery());
			ps.setDouble(1, price);
		ResultSet rs=ps.executeQuery();
		if(rs.next()) {
			Item item=new Item();
			item.setPrice(rs.getDouble(1));
			item.setId(rs.getInt(2));
			item.setName(rs.getString(3));
			item.setQuantity_in_stock(rs.getInt(4));
			items.add(item);
			
			
		}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			closeConnection();
		}
		return items;
	}
	//Arguments: The item price (type double) you�re testing against
	//Returns: A list of items (type List) which have a price value greater than the given price

	public List <Item>	getItemsInStock(){
		
ArrayList<Item> items= new ArrayList<Item>();
PreparedStatement ps;

try {
	ps=conn.prepareStatement(SQL.GETITEMSINSTOCK.getQuery());
	
ResultSet rs=ps.executeQuery();
while(rs.next()) {
	Item item=new Item();
	item.setId(rs.getInt("id"));
	item.setName(rs.getString("name"));
	item.setQuantity_in_stock(rs.getInt("quantity_in_stock"));
	item.setPrice(rs.getDouble("price"));
	items.add(item);
}
	
return items;
	
} catch (SQLException e) {
	// TODO Auto-generated catch block
	e.printStackTrace();
}
return items;

}
}
