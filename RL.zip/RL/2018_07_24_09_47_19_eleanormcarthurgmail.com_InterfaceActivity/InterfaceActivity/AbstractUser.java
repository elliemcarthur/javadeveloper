package org.perscholas.InterfaceActivity;

abstract class AbstractUser implements LibraryUser{

	int age;
	String bookType;
	
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	public String getBookType() {
		return bookType;
	}
	public void setBookType(String bookType) {
		this.bookType = bookType;
	}
	public void registerAccount() {
		// TODO Auto-generated method stub
		
	}
	
}
