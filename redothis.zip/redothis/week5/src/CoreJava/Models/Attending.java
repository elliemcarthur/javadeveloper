package CoreJava.Models;

import java.util.Scanner;

public class Attending {
	int courseId;
	String email;
	
	public Attending(){

		
	}
	public int getCourseId() {
		return courseId;
	}
	public void setCourseId(int courseId) {
		this.courseId = courseId;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	


}
