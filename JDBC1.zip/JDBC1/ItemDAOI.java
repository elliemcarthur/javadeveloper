package org.perscholas.JDBC1;

import java.util.List;

public interface ItemDAOI {
	/*
	public Item getItemById(int id);
	public List <Item >	getItemsCostingGreaterThan(double price);
	static final String getItemById="SELECT* FROM ITEM WHERE ID=?";
	static final String getItemsCostingGreaterThan="SELECT * FROM ITEM WHERE PRICE=?";
	static final String getItemsInStock="select * from item WHERE QUANTITY_IN_STOCK !=0";
*/
	enum SQL{
		GETITEMBYID("SELECT* FROM ITEM WHERE ID=?"),
		GETITEMSCOSTINGGREATERTHAN("SELECT * FROM ITEM WHERE PRICE=?"),
		GETITEMSINSTOCK("select * from item WHERE QUANTITY_IN_STOCK !=0");
		

		String query;
		
		SQL(String givenQuery){
			query = givenQuery;
		}
		
		String getQuery() {
			return query;
		}
		
	
	}
}




