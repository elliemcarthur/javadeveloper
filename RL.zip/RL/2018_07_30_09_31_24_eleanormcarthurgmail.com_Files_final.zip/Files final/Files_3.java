package org.perscholas.files;

import java.util.Scanner;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;


public class Files_3 {

	public static void main(String[] args) {
		Scanner reader=new Scanner(System.in);
		Student student1=new Student("Jordan", 11, 90);

		System.out.println(student1.getName());
		System.out.println(student1.getGrade());
		System.out.println(student1.getGpa());
		
		
		String nameFile="C:\\Users\\Students\\eclipse-workspace\\PerScholas\\src\\org\\perscholas\\files\\name";
		String gradeFile="C:\\Users\\Students\\eclipse-workspace\\PerScholas\\src\\org\\perscholas\\files\\grade";
		String gpaFile="C:\\Users\\Students\\eclipse-workspace\\PerScholas\\src\\org\\perscholas\\files\\gpa";
		
		File namef=new File(nameFile);
		File gradef= new File(gradeFile);	
		File gpaf = new File(gpaFile);
		try {
		FileWriter	writer = new FileWriter(namef, true);
		writer.write(student1.getName());
		
		
		FileWriter writergrade=new FileWriter(gradef, true);
		writergrade.write(String.valueOf(student1.getGrade()));
		
	
		FileWriter writergpa=new FileWriter(gpaf, true);
		writergpa.write(String.valueOf(student1.getGpa()));
		
		writer.close();
		writergrade.close();
		writergpa.close();
		} catch (IOException e) {
			System.out.println("Can't find file.");
			e.printStackTrace();
		}
		
		
		
		

	}

}
