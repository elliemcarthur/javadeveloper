package org.perscholas.JDBC1test;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import org.perscholas.JDBC1.Item;
import org.perscholas.JDBC1.ItemDAOI.SQL;

public class ItemDAO {

	public Item getItemById(int id){
	
	Item item = new Item();
	String sql="SELECT* FROM ITEM WHERE ID=?";
	PreparedStatement ps;
	Connection conn=null;
	try {
		conn=OracleConnecter.getConn();
		ps = conn.prepareStatement(sql);
		ps.setInt(1,id);
	ResultSet rs=ps.executeQuery();
	while(rs.next()) {
		item=new Item();
		item.setId(rs.getInt(1));
		item.setName(rs.getString(2));
		item.setQuantity_in_stock(rs.getInt(3));
		item.setPrice(rs.getDouble(4));
		
	}
	} catch (SQLException | ClassNotFoundException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}finally {
		if(!conn.equals(null)) {
			try {
				conn.close();
			}catch(SQLException e) {
				e.printStackTrace();
			}
		}
	}
	return item;
	
	
}

}
