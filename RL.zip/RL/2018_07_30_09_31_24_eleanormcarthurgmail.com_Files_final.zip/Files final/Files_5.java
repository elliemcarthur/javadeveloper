package org.perscholas.files;




import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Scanner;

public class Files_5 {

	private static final String String = null;

	public static ArrayList<Student> readFileStudents(String fileLocation, String FileName) throws FileNotFoundException {
		ArrayList<Student> stuArray = new ArrayList<Student>();
		File file = new File(fileLocation+FileName);
		Scanner reader = new Scanner(file);
	
		
	
		
		while (reader.hasNextLine()) {
			String[] lines = reader.nextLine().split(",");
			
			

				Student student=new Student();
			student.setName(lines[0]);
			student.setGrade(Integer.valueOf(lines[1]));
			student.setGpa(Double.valueOf(lines[2]));

			stuArray.add(student); 
	
			
			
		
		}
	
 		
		
		reader.close();
		return stuArray;
		
	} 

	
	public static void main(String[] args) {
		String fileLocation = "C:\\Users\\Students\\eclipse-workspace\\PerScholas\\src\\org\\perscholas\\files\\";
		String studentfile = "Student.csv";

		Student[] students=new Student[10];
			    students[0]=new Student("Josh", 12, 100);
			    students[1]=new Student("Jerry", 12, 90);
			    students[2]=new Student("Jet", 12, 89);
			    students[3]=new Student("Ellie", 12, 91);
			    students[4]=new Student("Robyn", 12, 96);
			    students[5]=new Student("Robert", 12, 78);
			    students[6]=new Student("Kyle", 12, 89);
			    students[7]=new Student("Eli", 12, 91);
			    students[8]=new Student("Kumar", 12, 70);
			    students[9]=new Student("Kiki", 12, 91);
			    
	   File file= new File(fileLocation, studentfile);


		FileWriter writer;
		try {
			writer = new FileWriter(file, true);
				for(int m=0; m<students.length; m++) {
			writer.write(students[m].getName() + ",");
			writer.write(java.lang.String.valueOf(students[m].getGrade() + ","));
		    writer.write(java.lang.String.valueOf(students[m].getGpa()) + "\n");
		}
		
			writer.close();
			
			ArrayList<Student> stuArray;

		
		stuArray=readFileStudents(fileLocation, studentfile);
		


	for (Student student : stuArray) {
		System.out.println(student.name + " " + student.grade + " " + student.gpa);
	}
		

		

		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}	
		
	
	

	}
}
